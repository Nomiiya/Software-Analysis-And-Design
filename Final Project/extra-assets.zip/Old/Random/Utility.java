//begin
import java.util.Scanner;
import java.util.*;
import java.io.*;
//end
public class Utility {

	public String getNextInput() {
		//begin
		Scanner in = new Scanner(System.in).useDelimiter("\\s*,\\s*");
		String input = in.next();
		return input;
		//end
	}

	public String getKeywords() {
		//begin
		Scanner in = new Scanner(System.in).useDelimiter("\\s*,\\s*");
		String input = in.next();
		return input;
		//end
	}

}
