public class Buyer {

	public String ID;

	public String subscribedWords[];

}
