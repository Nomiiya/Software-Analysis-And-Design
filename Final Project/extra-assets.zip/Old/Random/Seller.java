public class Seller {

	public String ID;

}
