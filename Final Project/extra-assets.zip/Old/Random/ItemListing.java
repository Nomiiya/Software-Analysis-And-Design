public class ItemListing {

	public String title;

	public int price;

	public String sellerID;

	public String Description;

}
