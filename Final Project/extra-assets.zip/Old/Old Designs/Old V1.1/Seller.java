public class Seller {

	public String sellerID;

	private Broker broker;

	private Event[] event;

	
	public void publishListing(Listing item) {
		//begin
		//end
	}

	public void modifyItem(int item, Seller seller) {
		//begin
		//end
	}

}
