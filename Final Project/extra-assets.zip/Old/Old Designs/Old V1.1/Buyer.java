public class Buyer {

	private String buyerID;

	public String[] subscribedList;

	private Broker broker;

	private Event[] event;

	public void subscribe(String keyword) {
		//begin
		//end
	}

	public void unsubscribe(String keyword) {
		//begin
		//end
	}

}
